# zzl 0.2.2

1.  添加beepr包中的`beep`函数
2.  增加`remindProgram()`函数

# zzl 0.2.1

1.  讲`codeGen()`中的api密钥设为环境变量，防止信息泄露
2.  增加函数`data2text()`

------------------------------------------------------------------------

# zzl 0.2.0

1.  修复`convertbackslash()`函数无法有效转换带有"\\u202a"标记的字符串

-   Initial CRAN submission.
